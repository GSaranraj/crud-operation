<?php
$db = mysqli_connect('localhost', 'root', '', 'crud');
if($db->connect_errno)
{
    echo $db->maxdb_connect_error;
    die();
}
else
{
	echo "database connected";
}
	//if(isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && isset($_POST['phone']))
	//{
		// include Database connection file 
		

		// get values 
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$email = $_POST['email'];
		$phone = $_POST['phone']

		$sql = "INSERT INTO test(firstname, lastname, emailid,phone) VALUES('$first_name', '$last_name', '$email','$phone')";
		if (!$result = mysqli_query($db,$sql)) {
	        exit(mysql_error());
	    }
	    echo "1 Record Added!";
	//}
?>